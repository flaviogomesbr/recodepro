import Jumbotron from './Jumbotron';
import Carousel  from './Carousel.jsx';


export default function Home(props){
    return(
        <div>
            <Jumbotron />
            <Carousel />

        </div>
        
    );

    }    