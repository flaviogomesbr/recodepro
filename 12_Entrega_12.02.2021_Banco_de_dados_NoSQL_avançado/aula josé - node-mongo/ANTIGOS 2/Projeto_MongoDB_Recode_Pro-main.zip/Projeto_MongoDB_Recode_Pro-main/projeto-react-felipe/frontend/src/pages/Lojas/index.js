import CardLoja from './CardLoja.jsx';

export default function Lojas(props){
    return (
        <CardLoja />
    );
}