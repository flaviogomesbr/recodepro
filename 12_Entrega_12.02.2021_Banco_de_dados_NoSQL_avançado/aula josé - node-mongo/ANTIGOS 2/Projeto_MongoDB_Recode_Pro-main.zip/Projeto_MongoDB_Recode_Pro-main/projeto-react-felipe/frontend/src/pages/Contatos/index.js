import Contato from './Contato';
import Form from './Form';

export default function ContatosPage(){
    return(
       <div className="container block">
           <Contato />
           <Form />
       </div> 
    );

} 