<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title> Página Inicial</title>
        <link href="css/estilo.css" rel="stylesheet">

    </head>
    <body>

        <!--menu-->

        <?php
        include('menu.html');
        ?>


    



    <p class="titulos"> Seja bem vindo (a)! </p>
        <br>
        <h3> Aqui em nossa loja, programadores tem desconto nos produtos para a sua casa!</font></h3>


        <br><br><br>
        <br><br><br>
        <br><br><br>
        <br><br><br>
        <br><br><br>
        
    <div class="footer">    
       Formas de pagamento
       <br>
       <img src="imagem/logop.jpg" width="380" height="100">
       <br>
       <p class="rodape"> &copy; Recode 2020</p>

    </div>




    </body>
</html>
