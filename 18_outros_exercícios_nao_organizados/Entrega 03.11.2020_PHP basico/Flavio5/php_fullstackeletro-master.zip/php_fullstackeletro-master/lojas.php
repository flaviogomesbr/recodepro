<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title> Nossas Lojas</title>
        <link href="css/estilo.css" rel="stylesheet">

    </head>
    <body>

    <?php
        include('menu.html');
    ?>
    
    <p class="titulos"> Nossas Lojas</p>
    <hr>
<div class="container">    
    <div class="lojas">
        Rio de Janeiro <br>
        Avenida Presidente Vargas, 5000<br>
        10 andar<br>
        Centro<br>
        (21) 9999-999
    </div>    

        
    <div class="lojas">
        São Paulo<br>
        Avenida Paulista, 985<br>
        3 andar<br>
        Jardins<br>
        (11) 1111-1111
    </div> 

        
    <div class="lojas">    

        Santa Catarina<br>
        Rua Major Ávila, 370<br>
        Vila Mariana<br>
        Centro<br>
        (47) 1234-5798
    </div>

</div>   



    <br><br><br>
    <br><br><br>
    <br><br><br>
    <br><br><br>
    <br><br><br>
        
    <div class="footer">    
       Formas de pagamento
       <br>
       <img src="imagem/logop.jpg" width="380" height="100">
       <br>
       <p class="rodape"> &copy; Recode 2020</p>

    </div>




    </body>
</html>