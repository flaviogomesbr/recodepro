function exibir_categoria(categoria){
    let elementos = document.getElementsByClassName('box_produtos');
    console.log(elementos);
    for(var i=0; i<elementos.length; i++){
        console.log(elementos[i].id);
        if(categoria == elementos[i].id) {
            elementos[i].style = "display:inline-block";
        } else {
            elementos[i].style = "display:none";
        }
   
       }
   }
   let exibir_todos = () => {
       let elementos = document.getElementsByClassName('box_produtos');
       
       for(var i=0; i<elementos.length; i++){
               elementos[i].style = "display:inline-block";
       }
   };
   
   let destaque1 = (imagem) => {
       console.log(imagem);
       if(imagem.width == 300)
           imagem.width = 150;
       else
           imagem.width = 300;
   };
   let destaque2 = (imagem) => {
       console.log(imagem);
       if(imagem.width == 300)
           imagem.width = 150;
       else
           imagem.width = 300;
   };
   let destaque3 = (imagem) => {
       console.log(imagem);
       if(imagem.width == 300)
           imagem.width = 150;
       else
           imagem.width = 300;
   };
   let destaque4 = (imagem) => {
       console.log(imagem);
       if(imagem.width == 300)
           imagem.width = 150;
       else
           imagem.width = 300;
   };
   let destaque5 = (imagem) => {
       console.log(imagem);
       if(imagem.width == 300)
           imagem.width = 150;
       else
           imagem.width = 300;
   };
   let destaque6 = (imagem) => {
       console.log(imagem);
       if(imagem.width == 300)
           imagem.width = 150;
       else
           imagem.width = 300;
   };
   let destaque7 = (imagem) => {
       console.log(imagem);
       if(imagem.width == 300)
           imagem.width = 150;
       else
           imagem.width = 300;
   };
   let destaque8 = (imagem) => {
       console.log(imagem);
       if(imagem.width == 300)
           imagem.width = 150;
       else
           imagem.width = 300;
   };
   let destaque9 = (imagem) => {
       console.log(imagem);
       if(imagem.width == 300)
           imagem.width = 150;
       else
           imagem.width = 300;
   };
   let destaque10 = (imagem) => {
       console.log(imagem);
       if(imagem.width == 300)
           imagem.width = 150;
       else
           imagem.width = 300;
   };
   let destaque11 = (imagem) => {
       console.log(imagem);
       if(imagem.width == 300)
           imagem.width = 150;
       else
           imagem.width = 300;
   };
   let destaque12 = (imagem) => {
       console.log(imagem);
       if(imagem.width == 300)
           imagem.width = 150;
       else
           imagem.width = 300;
   };
   let destaque13 = (imagem) => {
    console.log(imagem);
    if(imagem.width == 300)
        imagem.width = 150;
    else
        imagem.width = 300;
};

let destaque14 = (imagem) => {
    console.log(imagem);
    if(imagem.width == 300)
        imagem.width = 150;
    else
        imagem.width = 300;
};

let destaque15 = (imagem) => {
    console.log(imagem);
    if(imagem.width == 300)
        imagem.width = 150;
    else
        imagem.width = 300;
};

let destaque16 = (imagem) => {
    console.log(imagem);
    if(imagem.width == 300)
        imagem.width = 150;
    else
        imagem.width = 300;
};