<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="utf-8">
    <title>Nossa Comunidade</title>
    <link rel="stylesheet" href="./css/comunidade.css">
    <link rel="stylesheet" href="./css/global.css">
</head>

<body>
    <img src="./img/back3.jpeg">

</body>
