function updateBackgroundBlue() {
    document.body.style.backgroundColor = "blue"
}

function updateBackgroundRed() {
    document.body.style.backgroundColor = "red"
}

function updateBackgroundGreen() {
    document.body.style.backgroundColor = "green"
}