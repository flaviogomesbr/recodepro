# Projeto-Recode

Uma aplicação WEB que auxilie jovens surdos em situação de vulnerabilidade em seus processos de educação. Nessa plataforma  qualquer pessoa tem a  possibilidade de adicionar um vídeo de tradução de LIBRAS em vídeo falado. Ou seja, mesmo um vídeo sem acessibilidade pode se tornar acessível a partir da contribuição de pessoas surdas ou ouvintes.